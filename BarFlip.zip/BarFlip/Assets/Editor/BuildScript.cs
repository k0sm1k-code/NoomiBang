using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;

// Собирает APK. Сцена создаётся пустой: всё остальное строится кодом при запуске (Bootstrap.cs).
public static class BuildScript
{
    const string ScenePath = "Assets/Scenes/Main.unity";

    // ---- Настройки, которые можно поменять ----
    const string ProductName = "BarFlip";                 // название игры (рабочее)
    const string CompanyName = "BarFlipStudio";
    const string ApplicationId = "com.barflipstudio.barflip";
    // -------------------------------------------

    [MenuItem("BarFlip/Prepare Scene")]
    public static void PrepareScene()
    {
        Directory.CreateDirectory("Assets/Scenes");
        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        EditorSceneManager.SaveScene(scene, ScenePath);
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        AssetDatabase.SaveAssets();
    }

    // Шейдеры, которые игра ищет по имени. Без этого в сборке их вырежет, и всё станет розовым.
    static readonly string[] RequiredShaders =
    {
        "Standard", "Skybox/Procedural", "Unlit/Color", "Sprites/Default",
        "UI/Default", "Legacy Shaders/Diffuse"
    };

    static void AddAlwaysIncludedShaders()
    {
        UnityEngine.Object gs = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>("ProjectSettings/GraphicsSettings.asset");
        if (gs == null)
        {
            var all = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset");
            if (all != null && all.Length > 0) gs = all[0];
        }
        if (gs == null)
        {
            Debug.LogWarning("GraphicsSettings.asset не найден: шейдеры не добавлены.");
            return;
        }
        var so = new SerializedObject(gs);
        var arr = so.FindProperty("m_AlwaysIncludedShaders");
        foreach (string name in RequiredShaders)
        {
            Shader sh = Shader.Find(name);
            if (sh == null) continue;
            bool has = false;
            for (int i = 0; i < arr.arraySize; i++)
            {
                if (arr.GetArrayElementAtIndex(i).objectReferenceValue == sh) { has = true; break; }
            }
            if (has) continue;
            arr.arraySize++;
            arr.GetArrayElementAtIndex(arr.arraySize - 1).objectReferenceValue = sh;
        }
        so.ApplyModifiedProperties();
        AssetDatabase.SaveAssets();
    }

    [MenuItem("BarFlip/Build Android APK")]
    public static void BuildAndroid()
    {
        PrepareScene();
        AddAlwaysIncludedShaders();

        PlayerSettings.companyName = CompanyName;
        PlayerSettings.productName = ProductName;
        PlayerSettings.bundleVersion = "0.1.0";
        PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, ApplicationId);
        PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
        PlayerSettings.allowedAutorotateToPortrait = false;
        PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
        PlayerSettings.allowedAutorotateToLandscapeLeft = true;
        PlayerSettings.allowedAutorotateToLandscapeRight = true;
        PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
        PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARMv7 | AndroidArchitecture.ARM64;
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel23;
        PlayerSettings.Android.useCustomKeystore = false;
        EditorUserBuildSettings.buildAppBundle = false;
        EditorUserBuildSettings.androidBuildSystem = AndroidBuildSystem.Gradle;

        string dir = GetArg("-customBuildPath", "Builds/Android");
        // game-ci передаёт папку, но на всякий случай обработаем и путь к файлу
        string apkPath = dir.EndsWith(".apk", StringComparison.OrdinalIgnoreCase)
            ? dir
            : Path.Combine(dir, ProductName + ".apk");
        Directory.CreateDirectory(Path.GetDirectoryName(apkPath));

        var options = new BuildPlayerOptions
        {
            scenes = new[] { ScenePath },
            locationPathName = apkPath,
            target = BuildTarget.Android,
            options = BuildOptions.None
        };

        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result != BuildResult.Succeeded)
        {
            Debug.LogError("Сборка не удалась: " + report.summary.result);
            if (Application.isBatchMode) EditorApplication.Exit(1);
        }
        else
        {
            Debug.Log("APK готов: " + apkPath);
        }
    }

    static string GetArg(string name, string fallback)
    {
        string[] args = Environment.GetCommandLineArgs();
        for (int i = 0; i < args.Length - 1; i++)
            if (args[i] == name) return args[i + 1];
        return fallback;
    }
}
