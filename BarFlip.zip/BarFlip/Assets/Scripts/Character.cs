using System;
using System.Collections.Generic;
using UnityEngine;

public enum BodyPose { Relaxed = 0, Straight = 1, Tuck = 2, Arch = 3 }

// Физический человечек (рэгдолл) в полном 3D.
// Тело стоит лицом по локальной оси +X, поперечная ось тела (ось всех сгибов) = локальная Z.
// Сальто происходят вокруг этой оси, винт (закрутка) - вокруг продольной оси туловища.
public class Character : MonoBehaviour
{
    public const float FloorY = 0f;

    // размеры, метры
    const float TorsoH = 0.55f, TorsoW = 0.30f, TorsoD = 0.16f, HeadR = 0.11f;
    const float UArmL = 0.30f, FArmL = 0.28f, ArmR = 0.045f;
    const float ThighL = 0.42f, ShinL = 0.42f, LegR = 0.06f;
    const float ShoulderY = 0.245f, ArmZ = 0.11f, LegZ = 0.06f;
    const float GrabRadius = 0.17f;

    // высота кончика кисти над центром туловища, когда руки подняты вверх
    public const float HandTipY = ShoulderY + UArmL + FArmL;

    // Позы. Столбцы: бедро, колено, плечо (в полёте), плечо (на перекладине), локоть, шея, жёсткость.
    // Углы в градусах. Знак: плюс - против часовой стрелки, если смотреть со стороны -Z вдоль оси тела.
    static readonly float[][] PoseTable =
    {
        new[] {   0f,   -5f,    0f, 0f,  5f,   0f,  7f },   // расслабленно
        new[] {   0f,    0f,    0f, 0f,  0f,   0f, 24f },   // прямое тело
        new[] { 105f, -115f, -150f, 0f, 15f, -20f, 24f },   // группировка
        new[] { -35f,  -25f,   30f, 0f,  0f,  25f, 24f },   // прогиб
    };

    class Limb
    {
        public Rigidbody body, parent;
        public int kind;            // 0 бедро, 1 колено, 2 плечо, 3 локоть, 4 шея
        public float min, max, target, stiff, inertia;
    }

    public Rigidbody Torso { get; private set; }

    Rigidbody head;
    readonly Rigidbody[] upperArm = new Rigidbody[2];
    readonly Rigidbody[] foreArm = new Rigidbody[2];
    readonly Rigidbody[] thigh = new Rigidbody[2];
    readonly Rigidbody[] shin = new Rigidbody[2];
    readonly List<Rigidbody> all = new List<Rigidbody>();
    readonly List<Limb> limbs = new List<Limb>();
    readonly HingeJoint[] grips = new HingeJoint[2];
    readonly ConfigurableJoint[] pins = new ConfigurableJoint[2];

    public List<Bar> Bars;
    public BodyPose Pose = BodyPose.Relaxed;
    public bool TwistHeld;
    public float TwistSpeed = 1f;

    public Action<string, int> TrickPerformed;   // название, очки (только для красоты)
    public Action<Vector3> Regrabbed;            // перехват: позиция хвата
    public Action<Bar> GrabbedBar;               // за какую перекладину взялись

    float releaseCooldown;
    float freeTime;
    float emoteTimer;
    bool silent;

    // отслеживание трюка
    bool tracking;
    float flipAccum, twistAccum;
    readonly float[] poseTime = new float[4];

    public bool IsHanging { get { return grips[0] != null || grips[1] != null; } }
    public bool IsStuck { get { return pins[0] != null || pins[1] != null; } }
    public Bar CurrentBar { get; private set; }

    // ---------------------------------------------------------------------------------------
    // Создание
    // ---------------------------------------------------------------------------------------

    public static Character Create(Vector3 rootPos, Quaternion rot, Transform parent)
    {
        var go = new GameObject("Character");
        go.transform.SetParent(parent, false);
        go.transform.SetPositionAndRotation(rootPos, rot);
        var c = go.AddComponent<Character>();
        c.Build();
        return c;
    }

    // Часть тела. Позиция и поворот задаются в локальных координатах персонажа.
    GameObject MakePart(string name, PrimitiveType type, Vector3 localPos, Vector3 scale, Color color)
    {
        var g = GameObject.CreatePrimitive(type);
        g.name = name;
        g.transform.SetParent(transform, false);
        g.transform.localPosition = localPos;
        g.transform.localRotation = Quaternion.identity;
        g.transform.localScale = scale;
        g.GetComponent<Renderer>().sharedMaterial = WorldKit.Mat(color, 0.25f);
        return g;
    }

    Rigidbody AddBody(GameObject g, float mass, PhysicMaterial pm, float angDrag)
    {
        g.GetComponent<Collider>().sharedMaterial = pm;
        var rb = g.AddComponent<Rigidbody>();
        rb.mass = mass;
        rb.drag = 0.03f;
        rb.angularDrag = angDrag;
        rb.sleepThreshold = 0f;
        rb.interpolation = RigidbodyInterpolation.Interpolate;
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousSpeculative;
        rb.maxAngularVelocity = 40f;
        // не даём тонким конечностям иметь почти нулевой момент инерции (для устойчивости)
        Vector3 it = rb.inertiaTensor;
        rb.inertiaTensor = new Vector3(Mathf.Max(it.x, 0.01f), Mathf.Max(it.y, 0.01f), Mathf.Max(it.z, 0.01f));
        all.Add(rb);
        return rb;
    }

    void Build()
    {
        var pm = new PhysicMaterial("body");
        pm.dynamicFriction = 0.7f;
        pm.staticFriction = 0.8f;
        pm.bounciness = 0f;

        Color torsoC = new Color(0.62f, 0.62f, 0.62f);
        Color limbC = new Color(0.66f, 0.66f, 0.65f);
        Color headC = new Color(0.40f, 0.40f, 0.42f);

        // сначала создаём все объекты и ставим их на места, потом добавляем физику
        var gTorso = MakePart("Torso", PrimitiveType.Cube, Vector3.zero, new Vector3(TorsoW, TorsoH, TorsoD), torsoC);
        var gHead = MakePart("Head", PrimitiveType.Sphere, new Vector3(0f, TorsoH * 0.5f + 0.02f + HeadR, 0f),
            Vector3.one * (HeadR * 2f), headC);

        var gUA = new GameObject[2];
        var gFA = new GameObject[2];
        var gTh = new GameObject[2];
        var gSh = new GameObject[2];
        for (int s = 0; s < 2; s++)
        {
            float az = s == 0 ? ArmZ : -ArmZ;
            float lz = s == 0 ? LegZ : -LegZ;
            gUA[s] = MakePart("UpperArm" + s, PrimitiveType.Capsule,
                new Vector3(0f, ShoulderY + UArmL * 0.5f, az), new Vector3(ArmR * 2f, UArmL * 0.5f, ArmR * 2f), limbC);
            gFA[s] = MakePart("ForeArm" + s, PrimitiveType.Capsule,
                new Vector3(0f, ShoulderY + UArmL + FArmL * 0.5f, az), new Vector3(ArmR * 2f, FArmL * 0.5f, ArmR * 2f), limbC);
            gTh[s] = MakePart("Thigh" + s, PrimitiveType.Capsule,
                new Vector3(0f, -TorsoH * 0.5f - ThighL * 0.5f, lz), new Vector3(LegR * 2f, ThighL * 0.5f, LegR * 2f), limbC);
            gSh[s] = MakePart("Shin" + s, PrimitiveType.Capsule,
                new Vector3(0f, -TorsoH * 0.5f - ThighL - ShinL * 0.5f, lz), new Vector3(LegR * 2f, ShinL * 0.5f, LegR * 2f), limbC);
        }

        // физика
        Torso = AddBody(gTorso, 9f, pm, 0.2f);
        head = AddBody(gHead, 3f, pm, 0.4f);
        Connect(head, Torso, new Vector3(0f, TorsoH * 0.5f, 0f), 4, -40f, 40f, 0.05f);
        for (int s = 0; s < 2; s++)
        {
            float az = s == 0 ? ArmZ : -ArmZ;
            float lz = s == 0 ? LegZ : -LegZ;
            upperArm[s] = AddBody(gUA[s], 1.6f, pm, 0.35f);
            foreArm[s] = AddBody(gFA[s], 1.1f, pm, 0.35f);
            thigh[s] = AddBody(gTh[s], 4f, pm, 0.35f);
            shin[s] = AddBody(gSh[s], 3.2f, pm, 0.35f);

            Connect(upperArm[s], Torso, new Vector3(0f, ShoulderY, az), 2, -170f, 100f, 0.27f);
            Connect(foreArm[s], upperArm[s], new Vector3(0f, ShoulderY + UArmL, az), 3, -5f, 150f, 0.03f);
            Connect(thigh[s], Torso, new Vector3(0f, -TorsoH * 0.5f, lz), 0, -50f, 130f, 1.5f);
            Connect(shin[s], thigh[s], new Vector3(0f, -TorsoH * 0.5f - ThighL, lz), 1, -140f, 5f, 0.19f);
        }

        // части тела не сталкиваются друг с другом
        var cols = GetComponentsInChildren<Collider>();
        for (int i = 0; i < cols.Length; i++)
            for (int j = i + 1; j < cols.Length; j++)
                Physics.IgnoreCollision(cols[i], cols[j]);

        // шарниры на суставах: только для вида, как у деревянного манекена
        for (int s = 0; s < 2; s++)
        {
            float az = s == 0 ? ArmZ : -ArmZ;
            float lz = s == 0 ? LegZ : -LegZ;
            AddBall(upperArm[s], new Vector3(0f, ShoulderY, az), 0.058f, limbC);
            AddBall(foreArm[s], new Vector3(0f, ShoulderY + UArmL, az), 0.054f, limbC);
            AddBall(foreArm[s], new Vector3(0f, HandTipY, az), 0.052f, limbC);
            AddBall(thigh[s], new Vector3(0f, -TorsoH * 0.5f, lz), 0.068f, limbC);
            AddBall(shin[s], new Vector3(0f, -TorsoH * 0.5f - ThighL, lz), 0.066f, limbC);
        }
    }

    void AddBall(Rigidbody owner, Vector3 localPivot, float radius, Color color)
    {
        var g = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        Destroy(g.GetComponent<Collider>());
        g.name = "Joint";
        g.transform.SetParent(owner.transform, false);
        g.transform.position = transform.TransformPoint(localPivot);
        Vector3 ls = owner.transform.lossyScale;
        float d = radius * 2f;
        g.transform.localScale = new Vector3(d / ls.x, d / ls.y, d / ls.z);
        g.GetComponent<Renderer>().sharedMaterial = WorldKit.Mat(color, 0.3f);
    }

    // Шарнир между частями. pivotLocal задан в локальных координатах персонажа.
    void Connect(Rigidbody child, Rigidbody parent, Vector3 pivotLocal, int kind, float min, float max, float inertia)
    {
        Vector3 pivot = transform.TransformPoint(pivotLocal);
        var j = child.gameObject.AddComponent<HingeJoint>();
        j.connectedBody = parent;
        j.autoConfigureConnectedAnchor = false;
        j.anchor = child.transform.InverseTransformPoint(pivot);
        j.connectedAnchor = parent.transform.InverseTransformPoint(pivot);
        j.axis = Vector3.forward;        // поперечная ось тела
        j.enableCollision = false;
        limbs.Add(new Limb
        {
            body = child, parent = parent, kind = kind, min = min, max = max,
            inertia = inertia, target = 0f, stiff = 7f
        });
    }

    // ---------------------------------------------------------------------------------------
    // Управление
    // ---------------------------------------------------------------------------------------

    public void PlayEmote()
    {
        emoteTimer = 1.6f;
    }

    public void Release()
    {
        bool any = false;
        for (int h = 0; h < 2; h++)
        {
            if (grips[h] != null)
            {
                Destroy(grips[h]);
                grips[h] = null;
                any = true;
            }
        }
        if (any)
        {
            releaseCooldown = 0.4f;
            freeTime = 0f;
            CurrentBar = null;
        }
    }

    // Прилипание к полу: фиксирует стопы в мировой точке, но даёт телу свободно вращаться.
    public bool TryStick()
    {
        if (IsHanging || IsStuck) return false;
        int n = 0;
        for (int f = 0; f < 2; f++)
        {
            Vector3 foot = shin[f].position - shin[f].transform.up * (ShinL * 0.5f);
            if (foot.y > FloorY + 0.5f) continue;
            Vector3 anchor = new Vector3(foot.x, FloorY, foot.z);
            var j = shin[f].gameObject.AddComponent<ConfigurableJoint>();
            j.autoConfigureConnectedAnchor = false;
            j.anchor = shin[f].transform.InverseTransformPoint(foot);
            j.connectedAnchor = anchor;
            j.xMotion = ConfigurableJointMotion.Locked;
            j.yMotion = ConfigurableJointMotion.Locked;
            j.zMotion = ConfigurableJointMotion.Locked;
            j.angularXMotion = ConfigurableJointMotion.Free;
            j.angularYMotion = ConfigurableJointMotion.Free;
            j.angularZMotion = ConfigurableJointMotion.Free;
            j.enableCollision = false;
            pins[f] = j;
            n++;
        }
        return n > 0;
    }

    public void Unstick()
    {
        for (int f = 0; f < 2; f++)
        {
            if (pins[f] != null)
            {
                Destroy(pins[f]);
                pins[f] = null;
            }
        }
    }

    // Взяться за перекладину сразу (старт и сброс), без подсчёта перехвата.
    public void ForceGrip(Bar bar)
    {
        silent = true;
        for (int h = 0; h < 2; h++)
        {
            Vector3 tip = HandTip(h);
            Grab(h, bar, bar.Closest(tip));
        }
        silent = false;
        freeTime = 0f;
    }

    Vector3 HandTip(int h)
    {
        return foreArm[h].position + foreArm[h].transform.up * (FArmL * 0.5f);
    }

    void Grab(int h, Bar bar, Vector3 point)
    {
        var rb = foreArm[h];
        var j = rb.gameObject.AddComponent<HingeJoint>();
        j.autoConfigureConnectedAnchor = false;
        j.anchor = rb.transform.InverseTransformPoint(HandTip(h));
        j.connectedAnchor = point;                                   // без connectedBody это мировая точка
        j.axis = rb.transform.InverseTransformDirection(bar.Direction);
        j.enableCollision = false;
        grips[h] = j;
        CurrentBar = bar;
        if (!silent) OnGrabbed(bar, point);
    }

    void OnGrabbed(Bar bar, Vector3 point)
    {
        if (freeTime > 0.15f)
        {
            SaveData.Regrabs = SaveData.Regrabs + 1;
            if (Regrabbed != null) Regrabbed(point);
        }
        freeTime = 0f;
        EndTrick();
        if (GrabbedBar != null) GrabbedBar(bar);
    }

    void TryGrabAll()
    {
        if (releaseCooldown > 0f || Bars == null || IsStuck) return;
        for (int h = 0; h < 2; h++)
        {
            if (grips[h] != null) continue;
            Vector3 tip = HandTip(h);
            Bar best = null;
            Vector3 bestPoint = Vector3.zero;
            float bestD = GrabRadius;
            for (int i = 0; i < Bars.Count; i++)
            {
                Vector3 cp = Bars[i].Closest(tip);
                float d = (tip - cp).magnitude;
                if (d < bestD)
                {
                    bestD = d;
                    best = Bars[i];
                    bestPoint = cp;
                }
            }
            if (best != null) Grab(h, best, bestPoint);
        }
    }

    // ---------------------------------------------------------------------------------------
    // Физика каждый шаг
    // ---------------------------------------------------------------------------------------

    void FixedUpdate()
    {
        float dt = Time.fixedDeltaTime;
        if (releaseCooldown > 0f) releaseCooldown -= dt;
        if (emoteTimer > 0f) emoteTimer -= dt;
        if (!IsHanging) freeTime += dt;

        UpdatePoseTargets(dt);
        DriveLimbs();
        HandleTwist(dt);
        TryGrabAll();
        TrackTrick(dt);
    }

    void UpdatePoseTargets(float dt)
    {
        float[] row = PoseTable[(int)Pose];
        bool hanging = IsHanging;
        float em = emoteTimer > 0f ? Mathf.Sin(emoteTimer * 14f) * 25f : 0f;
        for (int i = 0; i < limbs.Count; i++)
        {
            Limb l = limbs[i];
            float tgt;
            switch (l.kind)
            {
                case 0: tgt = row[0] + em * 0.6f; break;
                case 1: tgt = row[1] - Mathf.Abs(em) * 0.8f; break;
                case 2: tgt = hanging ? row[3] : row[2] + em; break;
                case 3: tgt = row[4]; break;
                default: tgt = row[5]; break;
            }
            tgt = Mathf.Clamp(tgt, l.min, l.max);
            l.target = Mathf.MoveTowards(l.target, tgt, 420f * dt);
            l.stiff = l.kind == 4 ? row[6] * 0.6f : row[6];
        }
    }

    // Пружинно-демпферное управление суставами. Знак угла: SignedAngle вокруг поперечной оси тела.
    void DriveLimbs()
    {
        for (int i = 0; i < limbs.Count; i++)
        {
            Limb l = limbs[i];
            Vector3 axis = l.parent.transform.forward;
            float ang = Vector3.SignedAngle(l.parent.transform.up, l.body.transform.up, axis);
            float mid = (l.max + l.min + 360f) * 0.5f;
            if (ang > mid) ang -= 360f;       // чтобы переход через +-180 не ломал пределы

            float err = (l.target - ang) * Mathf.Deg2Rad;
            float w = Vector3.Dot(l.body.angularVelocity - l.parent.angularVelocity, axis);
            float wn = l.stiff;
            float tq = l.inertia * (wn * wn * err - 2f * wn * w);

            // мягкие пределы сустава
            if (ang < l.min) tq += l.inertia * 400f * (l.min - ang) * Mathf.Deg2Rad;
            else if (ang > l.max) tq -= l.inertia * 400f * (ang - l.max) * Mathf.Deg2Rad;

            float cap = l.inertia * 3000f;
            tq = Mathf.Clamp(tq, -cap, cap);
            l.body.AddTorque(axis * tq);
            l.parent.AddTorque(-axis * tq);
        }
    }

    // Винт: закрутка вокруг продольной оси туловища. Никакой привязки к плоскости нет, тело вращается свободно.
    void HandleTwist(float dt)
    {
        if (!TwistHeld || IsHanging || IsStuck) return;
        Vector3 up = Torso.transform.up;
        float w = Vector3.Dot(Torso.angularVelocity, up);
        float max = 13f * TwistSpeed;
        if (w < max)
        {
            for (int i = 0; i < all.Count; i++)
                all[i].AddTorque(up * (45f * TwistSpeed), ForceMode.Acceleration);
        }
    }

    // ---------------------------------------------------------------------------------------
    // Трюки (только для красоты)
    // ---------------------------------------------------------------------------------------

    bool Grounded()
    {
        float y = FloorY;
        if (Torso.position.y < y + 0.45f) return true;
        if (head.position.y < y + 0.3f) return true;
        for (int s = 0; s < 2; s++)
        {
            Vector3 foot = shin[s].position - shin[s].transform.up * (ShinL * 0.5f);
            if (foot.y < y + 0.16f) return true;
        }
        return false;
    }

    void TrackTrick(float dt)
    {
        bool air = !IsHanging && !IsStuck && !Grounded();
        if (air)
        {
            if (!tracking)
            {
                tracking = true;
                flipAccum = 0f;
                twistAccum = 0f;
                Array.Clear(poseTime, 0, poseTime.Length);
            }
            else
            {
                // сальто: вращение вокруг поперечной оси тела (плюс = назад)
                Vector3 w = Torso.angularVelocity;
                flipAccum += Vector3.Dot(w, Torso.transform.forward) * Mathf.Rad2Deg * dt;
                twistAccum += Vector3.Dot(w, Torso.transform.up) * Mathf.Rad2Deg * dt;
                poseTime[(int)Pose] += dt;
            }
        }
        else if (tracking)
        {
            EndTrick();
        }
    }

    void EndTrick()
    {
        if (!tracking) return;
        tracking = false;

        float total = Mathf.Abs(flipAccum);
        int n = total >= 300f ? Mathf.Max(1, Mathf.RoundToInt(total / 360f)) : 0;
        if (n == 0) return;

        // поза, в которой провели больше всего времени (расслабленное = прямое тело)
        float tStraight = poseTime[0] + poseTime[1];
        float tTuck = poseTime[2];
        float tArch = poseTime[3];
        string poseName = "в прямом теле";
        int basePts = 140;
        if (tTuck >= tStraight && tTuck >= tArch) { poseName = "в группировке"; basePts = 120; }
        else if (tArch >= tStraight && tArch >= tTuck) { poseName = "в прогибе"; basePts = 150; }

        string[] counts = { "", "Сальто", "Двойное сальто", "Тройное сальто", "Четверное сальто" };
        string flipName = n < counts.Length ? counts[n] : n + "-кратное сальто";
        bool back = flipAccum > 0f;
        string dir = back ? "назад" : "вперёд";

        int tw = Mathf.RoundToInt(Mathf.Abs(twistAccum) / 360f);
        string twist = "";
        if (tw == 1) twist = " с винтом";
        else if (tw > 1) twist = " с " + tw + " винтами";

        int pts = n * basePts + tw * 80;
        if (TrickPerformed != null) TrickPerformed(flipName + " " + dir + " " + poseName + twist, pts);
    }
}
