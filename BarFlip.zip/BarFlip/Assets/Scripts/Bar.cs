using UnityEngine;

// Перекладина: отрезок между точками A и B (идёт вдоль оси Z, к камере).
// Физического коллайдера нет: хват проверяется расстоянием от кисти до отрезка.
public class Bar : MonoBehaviour
{
    public Vector3 A;
    public Vector3 B;
    public Renderer Rend;

    public Vector3 Direction
    {
        get { return (B - A).normalized; }
    }

    public Vector3 Closest(Vector3 p)
    {
        Vector3 ab = B - A;
        float t = Mathf.Clamp01(Vector3.Dot(p - A, ab) / ab.sqrMagnitude);
        return A + ab * t;
    }

    public void SetColor(Color c)
    {
        if (Rend != null) Rend.material.color = c;
    }

    public static Bar Create(Transform parent, string name, Vector3 a, Vector3 b, Color color)
    {
        var g = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        g.name = name;
        g.transform.SetParent(parent, false);
        Vector3 dir = (b - a).normalized;
        float len = (b - a).magnitude;
        g.transform.localPosition = (a + b) * 0.5f;
        g.transform.localRotation = Quaternion.FromToRotation(Vector3.up, dir);
        g.transform.localScale = new Vector3(0.11f, len * 0.5f, 0.11f);
        Object.Destroy(g.GetComponent<Collider>());
        var r = g.GetComponent<Renderer>();
        r.sharedMaterial = WorldKit.Mat(color, 0.35f);
        var bar = g.AddComponent<Bar>();
        bar.A = a;
        bar.B = b;
        bar.Rend = r;
        return bar;
    }
}
