using UnityEngine;

// Держит объект в небе на заданном направлении от камеры (как часть неба) и разворачивает его к камере.
// Используется для солнечного свечения.
public class SkyFollow : MonoBehaviour
{
    public Transform Cam;
    public Vector3 Dir = Vector3.forward;
    public float Dist = 250f;

    void LateUpdate()
    {
        if (Cam == null) return;
        transform.position = Cam.position + Dir * Dist;
        transform.rotation = Quaternion.LookRotation(transform.position - Cam.position);
    }
}
