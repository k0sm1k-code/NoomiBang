using System.Collections.Generic;
using UnityEngine;

// Иконки-человечки для кнопок, нарисованные кодом (белые линии на прозрачном фоне).
// Имена: hang, twist, stand, arch, tuck, straight.
public static class IconKit
{
    class Shape
    {
        public bool circle;
        public Vector2 a, b;      // отрезок или (центр, радиус в a.x)
        public bool filled;
        public float width;
    }

    static readonly Dictionary<string, Sprite> cache = new Dictionary<string, Sprite>();

    public static Sprite Get(string name)
    {
        Sprite s;
        if (cache.TryGetValue(name, out s) && s != null) return s;
        s = Build(name);
        cache[name] = s;
        return s;
    }

    static void Line(List<Shape> l, float x0, float y0, float x1, float y1, float w = 0.07f)
    {
        l.Add(new Shape { a = new Vector2(x0, y0), b = new Vector2(x1, y1), width = w });
    }

    static void Poly(List<Shape> l, float[] pts, float w = 0.07f)
    {
        for (int i = 0; i + 3 < pts.Length; i += 2)
            Line(l, pts[i], pts[i + 1], pts[i + 2], pts[i + 3], w);
    }

    static void Circle(List<Shape> l, float cx, float cy, float r, bool filled, float w = 0.05f)
    {
        l.Add(new Shape { circle = true, a = new Vector2(cx, cy), b = new Vector2(r, 0f), filled = filled, width = w });
    }

    static Sprite Build(string name)
    {
        var s = new List<Shape>();
        switch (name)
        {
            case "hang":       // человечек висит на перекладине
                Line(s, 0.18f, 0.90f, 0.82f, 0.90f, 0.08f);
                Line(s, 0.40f, 0.90f, 0.47f, 0.62f);
                Line(s, 0.60f, 0.90f, 0.53f, 0.62f);
                Circle(s, 0.50f, 0.70f, 0.065f, true);
                Line(s, 0.50f, 0.60f, 0.50f, 0.36f);
                Line(s, 0.50f, 0.36f, 0.41f, 0.12f);
                Line(s, 0.50f, 0.36f, 0.59f, 0.12f);
                break;
            case "twist":      // винт: круговая стрелка вокруг тела
                Line(s, 0.50f, 0.78f, 0.50f, 0.22f);
                Circle(s, 0.50f, 0.84f, 0.06f, true);
                for (int i = 0; i < 24; i++)
                {
                    float a0 = (40f + i * 11f) * Mathf.Deg2Rad;
                    float a1 = (40f + (i + 1) * 11f) * Mathf.Deg2Rad;
                    Line(s, 0.5f + 0.38f * Mathf.Cos(a0), 0.5f + 0.38f * Mathf.Sin(a0),
                        0.5f + 0.38f * Mathf.Cos(a1), 0.5f + 0.38f * Mathf.Sin(a1), 0.05f);
                }
                Line(s, 0.5f + 0.38f * Mathf.Cos(40f * Mathf.Deg2Rad), 0.5f + 0.38f * Mathf.Sin(40f * Mathf.Deg2Rad),
                    0.80f, 0.62f, 0.05f);
                Line(s, 0.5f + 0.38f * Mathf.Cos(40f * Mathf.Deg2Rad), 0.5f + 0.38f * Mathf.Sin(40f * Mathf.Deg2Rad),
                    0.66f, 0.84f, 0.05f);
                break;
            case "stand":      // человечек присел на пол
                Line(s, 0.12f, 0.08f, 0.88f, 0.08f, 0.05f);
                Circle(s, 0.52f, 0.78f, 0.07f, true);
                Poly(s, new[] { 0.50f, 0.68f, 0.46f, 0.46f, 0.34f, 0.30f, 0.44f, 0.12f });
                Poly(s, new[] { 0.46f, 0.46f, 0.62f, 0.30f, 0.58f, 0.12f });
                Line(s, 0.49f, 0.62f, 0.66f, 0.52f);
                break;
            case "arch":       // прогиб: дуга с точкой-головой
                Circle(s, 0.30f, 0.86f, 0.065f, true);
                for (int i = 0; i < 16; i++)
                {
                    float t0 = i / 16f, t1 = (i + 1) / 16f;
                    Line(s, 0.36f + 0.28f * Mathf.Sin(Mathf.PI * t0), 0.78f - 0.72f * t0,
                        0.36f + 0.28f * Mathf.Sin(Mathf.PI * t1), 0.78f - 0.72f * t1, 0.07f);
                }
                break;
            case "tuck":       // группировка: свернувшийся человечек
                Circle(s, 0.40f, 0.84f, 0.065f, true);
                Poly(s, new[] { 0.44f, 0.74f, 0.62f, 0.60f, 0.62f, 0.40f, 0.44f, 0.30f, 0.56f, 0.12f });
                Line(s, 0.62f, 0.60f, 0.40f, 0.52f);
                break;
            default:           // straight: вытянутый столбик
                Circle(s, 0.50f, 0.86f, 0.065f, true);
                Line(s, 0.50f, 0.74f, 0.50f, 0.08f, 0.08f);
                break;
        }
        return Rasterize(s, 96);
    }

    static float DistToSegment(Vector2 p, Vector2 a, Vector2 b)
    {
        Vector2 ab = b - a;
        float t = Mathf.Clamp01(Vector2.Dot(p - a, ab) / Mathf.Max(ab.sqrMagnitude, 1e-6f));
        return Vector2.Distance(p, a + ab * t);
    }

    static Sprite Rasterize(List<Shape> shapes, int n)
    {
        var tex = new Texture2D(n, n, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;
        tex.wrapMode = TextureWrapMode.Clamp;
        var px = new Color32[n * n];
        for (int y = 0; y < n; y++)
        {
            for (int x = 0; x < n; x++)
            {
                var p = new Vector2((x + 0.5f) / n, (y + 0.5f) / n);
                float best = 0f;
                for (int i = 0; i < shapes.Count; i++)
                {
                    Shape sh = shapes[i];
                    float d;
                    if (sh.circle)
                    {
                        float r = sh.b.x;
                        float dc = Vector2.Distance(p, sh.a);
                        float a;
                        if (sh.filled)
                        {
                            d = Mathf.Max(0f, dc - r);
                            a = Mathf.Clamp01(1f - d * n);
                        }
                        else
                        {
                            d = Mathf.Abs(dc - r);
                            a = Mathf.Clamp01(sh.width * 0.5f * n - d * n + 0.5f);
                        }
                        best = Mathf.Max(best, a);
                    }
                    else
                    {
                        d = DistToSegment(p, sh.a, sh.b);
                        float a = Mathf.Clamp01(sh.width * 0.5f * n - d * n + 0.5f);
                        best = Mathf.Max(best, a);
                    }
                }
                px[y * n + x] = new Color32(255, 255, 255, (byte)Mathf.RoundToInt(best * 255f));
            }
        }
        tex.SetPixels32(px);
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, n, n), new Vector2(0.5f, 0.5f), 100f);
    }
}
