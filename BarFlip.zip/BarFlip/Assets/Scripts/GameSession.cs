using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Режим игры: карта, персонаж, кнопки на экране, пауза.
public class GameSession : MonoBehaviour
{
    public string mapId = "classic";

    Camera cam;
    CameraRig rig;
    List<Bar> bars;
    Character ch;
    Transform world;
    int spawnIndex;

    // экран
    Canvas canvas;
    Text counterText, trickTitle, trickPts, plusText, mainLabel, stickLabel, spawnNumber;
    HoldButton btnMain, btnStick, btnArch, btnTuck, btnStraight, btnReset, btnEmote, btnMenu;
    bool twistArmed;
    float trickTimer, plusTimer;
    Sprite spHang, spTwist;
    Image iconMain;

    // пауза
    GameObject pausePanel;
    bool paused;
    int slowIdx, gravIdx, zoomIdx = 1, twistIdx = 1;
    static readonly float[] SlowVals = { 1f, 0.5f, 0.25f, 0.1f };
    static readonly string[] SlowNames = { "Нет", "x0.5", "x0.25", "x0.1" };
    static readonly float[] GravVals = { 1f, 0.5f, 1.5f };
    static readonly string[] GravNames = { "Обычная", "Низкая", "Высокая" };
    static readonly float[] ZoomVals = { 0.75f, 1f, 1.4f };
    static readonly string[] ZoomNames = { "Близко", "Обычно", "Далеко" };
    static readonly float[] TwistVals = { 0.6f, 1f, 1.6f };
    static readonly string[] TwistNames = { "Медленно", "Обычная", "Быстро" };

    static readonly Color PanelCol = new Color(0.17f, 0.29f, 0.47f, 0.50f);
    static readonly Color PanelDown = new Color(0.05f, 0.09f, 0.16f, 0.72f);
    static readonly Color PanelLight = new Color(0.40f, 0.47f, 0.58f, 0.55f);

    void Start()
    {
        cam = GameManager.I.Cam;
        world = new GameObject("World").transform;
        world.SetParent(transform, false);

        WorldKit.SetupEnvironment(world, cam);
        bars = ClassicMap.Build(world);

        rig = gameObject.AddComponent<CameraRig>();
        rig.Cam = cam;
        rig.Dist = 7.5f;
        rig.MinY = 2.4f;

        // стартуем с перекладины в середине карты
        spawnIndex = 0;
        for (int i = 0; i < bars.Count; i++)
        {
            if (Mathf.Abs(bars[i].A.x) < 0.1f) { spawnIndex = i; break; }
        }

        BuildHud();
        BuildPause();
        Respawn();
    }

    // ---------------------------------------------------------------------------------------
    // Персонаж
    // ---------------------------------------------------------------------------------------

    void Respawn()
    {
        if (ch != null)
        {
            ch.gameObject.SetActive(false);
            Destroy(ch.gameObject);
        }
        Bar bar = bars[spawnIndex];
        Vector3 d = bar.Direction;
        d.y = 0f;
        if (d.sqrMagnitude < 0.001f) d = Vector3.forward;
        d.Normalize();
        if (d.z < 0f) d = -d;

        Vector3 mid = (bar.A + bar.B) * 0.5f;
        Quaternion rot = Quaternion.LookRotation(d, Vector3.up);
        Vector3 root = mid - Vector3.up * Character.HandTipY;

        ch = Character.Create(root, rot, transform);
        ch.Bars = bars;
        ch.TrickPerformed += OnTrick;
        ch.Regrabbed += OnRegrab;
        ch.GrabbedBar += OnGrabbedBar;
        ApplySettings();
        ch.ForceGrip(bar);

        rig.Target = ch.Torso.transform;
        rig.TargetYaw = Mathf.Atan2(d.x, d.z) * Mathf.Rad2Deg;
        rig.Snap();
        twistArmed = false;
        if (spawnNumber != null) spawnNumber.text = (spawnIndex + 1).ToString();
    }

    void ApplySettings()
    {
        Physics.gravity = new Vector3(0f, -9.81f * GravVals[gravIdx], 0f);
        if (rig != null) rig.Zoom = ZoomVals[zoomIdx];
        if (ch != null) ch.TwistSpeed = TwistVals[twistIdx];
        if (!paused) Time.timeScale = SlowVals[slowIdx];
    }

    void OnTrick(string title, int pts)
    {
        trickTitle.text = title;
        trickPts.text = "+" + pts;
        trickTimer = 2.2f;
    }

    void OnRegrab(Vector3 pos)
    {
        plusTimer = 0.9f;
        StartCoroutine(Burst(pos));
        if (SaveData.Regrabs % 10 == 0) SaveData.Flush();
    }

    void OnGrabbedBar(Bar bar)
    {
        rig.LookAlong(bar.Direction);
    }

    // Белая вспышка вокруг руки при перехвате
    IEnumerator Burst(Vector3 pos)
    {
        var g = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        Destroy(g.GetComponent<Collider>());
        g.transform.SetParent(transform, false);
        g.transform.position = pos;
        var shader = Shader.Find("Sprites/Default");
        var m = new Material(shader);
        g.GetComponent<Renderer>().sharedMaterial = m;
        float t = 0f;
        const float dur = 0.45f;
        while (t < dur)
        {
            t += Time.unscaledDeltaTime;
            float k = Mathf.Clamp01(t / dur);
            g.transform.localScale = Vector3.one * Mathf.Lerp(0.2f, 2.2f, k);
            m.color = new Color(1f, 1f, 1f, 0.7f * (1f - k));
            yield return null;
        }
        Destroy(g);
        Destroy(m);
    }

    // ---------------------------------------------------------------------------------------
    // Кнопки на экране (раскладка как в оригинальной игре, опорное разрешение 1600x720)
    // ---------------------------------------------------------------------------------------

    HoldButton AddPanel(string name, Color n, Color d, float x, float y, float w, float h, bool right, out Text lab)
    {
        var hb = UiKit.MakeHold(canvas.transform, name, "", 24, n, d, out lab);
        var rt = (RectTransform)hb.transform;
        if (right) UiKit.PlaceTopRight(rt, x, y, w, h);
        else UiKit.PlaceTopLeft(rt, x, y, w, h);
        return hb;
    }

    static Image AddIcon(Transform parent, string icon, Vector2 anchor, Vector2 pos, float size)
    {
        var go = new GameObject("Icon", typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        var img = go.GetComponent<Image>();
        img.sprite = IconKit.Get(icon);
        img.color = new Color(1f, 1f, 1f, 0.92f);
        img.raycastTarget = false;
        UiKit.Place((RectTransform)go.transform, anchor, new Vector2(0.5f, 0.5f), pos, new Vector2(size, size));
        return img;
    }

    // Положение подписи внутри кнопки: доли (0..1) и отступы
    static void LabelRect(Text t, float x0, float y0, float x1, float y1, float padLeft, TextAnchor al, int size)
    {
        var r = t.rectTransform;
        r.anchorMin = new Vector2(x0, y0);
        r.anchorMax = new Vector2(x1, y1);
        r.offsetMin = new Vector2(padLeft, 0f);
        r.offsetMax = Vector2.zero;
        t.alignment = al;
        t.fontSize = size;
    }

    // Кнопка справа: иконка слева, подпись по центру по высоте
    HoldButton AddSideButton(string name, string label, string icon, float y, float h, out Text lab)
    {
        var hb = AddPanel(name, PanelCol, PanelDown, 10f, y, 280f, h, true, out lab);
        lab.text = label;
        LabelRect(lab, 0f, 0f, 1f, 1f, 65f, TextAnchor.MiddleLeft, 24);
        AddIcon(hb.transform, icon, new Vector2(0f, 0.5f), new Vector2(32f, 0f), 44f);
        return hb;
    }

    void BuildHud()
    {
        canvas = UiKit.CreateCanvas("HUD", 10, transform);
        spHang = IconKit.Get("hang");
        spTwist = IconKit.Get("twist");
        Text lab;

        // слева сверху: Отпустить (на перекладине) или Винт (в воздухе)
        btnMain = AddPanel("Main", PanelCol, PanelDown, 0f, 10f, 350f, 346f, false, out mainLabel);
        mainLabel.text = "Отпустить";
        LabelRect(mainLabel, 0f, 0.10f, 1f, 0.30f, 0f, TextAnchor.MiddleCenter, 24);
        iconMain = AddIcon(btnMain.transform, "hang", new Vector2(0.5f, 0.62f), Vector2.zero, 64f);
        btnMain.Pressed += () =>
        {
            if (ch == null) return;
            twistArmed = !ch.IsHanging;
            if (ch.IsHanging) ch.Release();
        };
        btnMain.Released += () => { twistArmed = false; };

        // слева снизу: Прилипание / Отлипание
        btnStick = AddPanel("Stick", PanelCol, PanelDown, 0f, 364f, 350f, 346f, false, out stickLabel);
        stickLabel.text = "Прилипание";
        LabelRect(stickLabel, 0f, 0.38f, 1f, 0.62f, 95f, TextAnchor.MiddleLeft, 24);
        AddIcon(btnStick.transform, "stand", new Vector2(0f, 0.5f), new Vector2(54f, 0f), 44f);
        btnStick.Pressed += () =>
        {
            if (ch == null) return;
            if (ch.IsStuck) ch.Unstick(); else ch.TryStick();
        };

        // справа: три позы
        btnArch = AddSideButton("Arch", "Прогиб", "arch", 10f, 226f, out lab);
        btnTuck = AddSideButton("Tuck", "Группировка", "tuck", 244f, 226f, out lab);
        btnStraight = AddSideButton("Straight", "Прямое тело", "straight", 480f, 224f, out lab);

        // снизу: меню, сброс, эмоции
        btnMenu = AddPanel("Menu", PanelLight, PanelDown, 380f, 476f, 100f, 100f, false, out lab);
        lab.text = "\u2261";
        lab.fontSize = 46;
        btnMenu.Pressed += () => SetPaused(true);

        btnReset = AddPanel("Reset", PanelCol, PanelDown, 380f, 586f, 204f, 118f, false, out lab);
        lab.text = "Сброс";
        lab.fontSize = 22;
        btnReset.Pressed += () => Respawn();

        btnEmote = AddPanel("Emote", PanelCol, PanelDown, 600f, 636f, 116f, 64f, false, out lab);
        lab.text = "Эмоции";
        lab.fontSize = 20;
        btnEmote.Pressed += () => { if (ch != null) ch.PlayEmote(); };

        // счётчик перехватов вверху по центру
        var cp = UiKit.Panel(canvas.transform, "Counter", new Color(0.22f, 0.28f, 0.37f, 0.82f), true, true);
        UiKit.Place(cp, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), Vector2.zero, new Vector2(342f, 46f));
        counterText = UiKit.Label(cp, SaveData.RegrabsText(SaveData.Regrabs), 34, Color.white,
            TextAnchor.MiddleCenter, FontStyle.Normal);
        var cOl = counterText.gameObject.AddComponent<Outline>();
        cOl.effectColor = new Color(0f, 0f, 0f, 0.55f);
        cOl.effectDistance = new Vector2(2f, -2f);

        // +1 рядом со счётчиком
        var pp = UiKit.Panel(canvas.transform, "Plus", new Color(0f, 0f, 0f, 0f), false);
        UiKit.Place(pp, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(230f, -4f), new Vector2(100f, 46f));
        plusText = UiKit.Label(pp, "+1", 34, new Color(1f, 1f, 1f, 0f), TextAnchor.MiddleCenter, FontStyle.Bold);

        // название трюка и очки (только для красоты)
        var tp = UiKit.Panel(canvas.transform, "TrickTitle", new Color(0f, 0f, 0f, 0f), false);
        UiKit.Place(tp, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -70f), new Vector2(900f, 60f));
        trickTitle = UiKit.Label(tp, "", 40, new Color(1f, 1f, 1f, 0f), TextAnchor.MiddleCenter, FontStyle.Bold);
        var ol = trickTitle.gameObject.AddComponent<Outline>();
        ol.effectColor = new Color(0f, 0f, 0f, 0.5f);
        ol.effectDistance = new Vector2(2f, -2f);
        var tpp = UiKit.Panel(canvas.transform, "TrickPts", new Color(0f, 0f, 0f, 0f), false);
        UiKit.Place(tpp, new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(0f, -128f), new Vector2(300f, 40f));
        trickPts = UiKit.Label(tpp, "", 28, new Color(1f, 0.82f, 0.3f, 0f), TextAnchor.MiddleCenter, FontStyle.Bold);
    }

    // ---------------------------------------------------------------------------------------
    // Пауза
    // ---------------------------------------------------------------------------------------

    void BuildPause()
    {
        pausePanel = new GameObject("Pause", typeof(RectTransform));
        pausePanel.transform.SetParent(canvas.transform, false);
        UiKit.Stretch((RectTransform)pausePanel.transform);

        var dim = UiKit.Panel(pausePanel.transform, "Dim", new Color(0f, 0f, 0f, 0.40f), false);
        UiKit.Stretch(dim);

        var left = UiKit.Panel(pausePanel.transform, "Left", new Color(0.09f, 0.09f, 0.10f, 0.96f), false);
        left.anchorMin = new Vector2(0f, 0f);
        left.anchorMax = new Vector2(0f, 1f);
        left.pivot = new Vector2(0f, 0.5f);
        left.sizeDelta = new Vector2(300f, 0f);
        left.anchoredPosition = Vector2.zero;

        var dark = new Color(0.20f, 0.20f, 0.22f, 1f);
        var home = UiKit.MakeButton(left, "Меню", 24, dark, Color.white, () => GameManager.I.ShowMenu());
        UiKit.PlaceTopLeft((RectTransform)home.transform, 10f, 10f, 135f, 72f);
        var restart = UiKit.MakeButton(left, "Заново", 24, dark, Color.white, () => { Respawn(); });
        UiKit.PlaceTopLeft((RectTransform)restart.transform, 155f, 10f, 135f, 72f);

        AddSelector(left, "Замедление", 100f, SlowNames, slowIdx, i => { slowIdx = i; ApplySettings(); });
        AddSelector(left, "Гравитация", 198f, GravNames, gravIdx, i => { gravIdx = i; ApplySettings(); });
        AddSelector(left, "Масштаб камеры", 296f, ZoomNames, zoomIdx, i => { zoomIdx = i; ApplySettings(); });
        AddSelector(left, "Скорость винта", 394f, TwistNames, twistIdx, i => { twistIdx = i; ApplySettings(); });
        AddSpawnSelector(left, 492f);

        var close = UiKit.MakeButton(left, "X", 36, dark, Color.white, () => SetPaused(false));
        UiKit.PlaceTopLeft((RectTransform)close.transform, 10f, 620f, 90f, 80f);

        pausePanel.SetActive(false);
    }

    void AddSelector(Transform parent, string title, float y, string[] names, int start, Action<int> onChange)
    {
        int idx = start;
        var row = UiKit.Panel(parent, "Selector", new Color(0.16f, 0.16f, 0.17f, 1f));
        UiKit.PlaceTopLeft(row, 10f, y, 280f, 90f);
        var t = UiKit.Label(row, title, 20, new Color(0.75f, 0.75f, 0.75f), TextAnchor.UpperCenter);
        t.rectTransform.offsetMax = new Vector2(0f, -6f);
        var val = UiKit.Label(row, names[idx], 28, Color.white, TextAnchor.LowerCenter, FontStyle.Bold);
        val.rectTransform.offsetMin = new Vector2(0f, 12f);

        var clear = new Color(1f, 1f, 1f, 0.10f);
        var b1 = UiKit.MakeButton(row, "<", 32, clear, Color.white, () =>
        {
            idx = (idx - 1 + names.Length) % names.Length;
            val.text = names[idx];
            onChange(idx);
        });
        UiKit.Place((RectTransform)b1.transform, new Vector2(0f, 0f), new Vector2(0f, 0f), new Vector2(6f, 8f), new Vector2(58f, 48f));
        var b2 = UiKit.MakeButton(row, ">", 32, clear, Color.white, () =>
        {
            idx = (idx + 1) % names.Length;
            val.text = names[idx];
            onChange(idx);
        });
        UiKit.Place((RectTransform)b2.transform, new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(-6f, 8f), new Vector2(58f, 48f));
    }

    void AddSpawnSelector(Transform parent, float y)
    {
        var row = UiKit.Panel(parent, "Spawn", new Color(0.16f, 0.16f, 0.17f, 1f));
        UiKit.PlaceTopLeft(row, 10f, y, 280f, 90f);
        var t = UiKit.Label(row, "Спавн", 20, new Color(0.75f, 0.75f, 0.75f), TextAnchor.UpperCenter);
        t.rectTransform.offsetMax = new Vector2(0f, -6f);
        spawnNumber = UiKit.Label(row, (spawnIndex + 1).ToString(), 30, Color.white, TextAnchor.LowerCenter, FontStyle.Bold);
        spawnNumber.rectTransform.offsetMin = new Vector2(0f, 12f);

        var clear = new Color(1f, 1f, 1f, 0.10f);
        AddSpawnButton(row, "|<", 6f, () => SetSpawn(0));
        AddSpawnButton(row, "<", 62f, () => SetSpawn(spawnIndex - 1));
        AddSpawnButton(row, ">", 170f, () => SetSpawn(spawnIndex + 1));
        AddSpawnButton(row, ">|", 226f, () => SetSpawn(bars.Count - 1));
    }

    void AddSpawnButton(Transform row, string label, float x, UnityEngine.Events.UnityAction act)
    {
        var b = UiKit.MakeButton(row, label, 26, new Color(1f, 1f, 1f, 0.10f), Color.white, act);
        UiKit.Place((RectTransform)b.transform, new Vector2(0f, 0f), new Vector2(0f, 0f), new Vector2(x, 8f), new Vector2(48f, 48f));
    }

    void SetSpawn(int i)
    {
        spawnIndex = Mathf.Clamp(i, 0, bars.Count - 1);
        Respawn();
    }

    void SetPaused(bool p)
    {
        paused = p;
        pausePanel.SetActive(p);
        Time.timeScale = p ? 0f : SlowVals[slowIdx];
    }

    // ---------------------------------------------------------------------------------------

    void Update()
    {
        if (ch == null) return;

        ch.Pose = btnTuck.Held ? BodyPose.Tuck
            : btnArch.Held ? BodyPose.Arch
            : btnStraight.Held ? BodyPose.Straight
            : BodyPose.Relaxed;
        ch.TwistHeld = btnMain.Held && twistArmed;

        mainLabel.text = ch.IsHanging ? "Отпустить" : "Винт";
        stickLabel.text = ch.IsStuck ? "Отлипание" : "Прилипание";
        Sprite wantIcon = ch.IsHanging ? spHang : spTwist;
        if (iconMain != null && iconMain.sprite != wantIcon) iconMain.sprite = wantIcon;
        counterText.text = SaveData.RegrabsText(SaveData.Regrabs);

        float dt = Time.unscaledDeltaTime;
        if (trickTimer > 0f)
        {
            trickTimer -= dt;
            float a = Mathf.Clamp01(trickTimer / 0.5f);
            trickTitle.color = new Color(1f, 1f, 1f, a);
            trickPts.color = new Color(1f, 0.82f, 0.3f, a);
        }
        if (plusTimer > 0f)
        {
            plusTimer -= dt;
            plusText.color = new Color(1f, 1f, 1f, Mathf.Clamp01(plusTimer / 0.4f));
        }

        if (!paused && (ch.Torso.position.y < -25f || ch.Torso.position.magnitude > 150f)) Respawn();
        if (Input.GetKeyDown(KeyCode.Escape)) SetPaused(!paused);
    }

    void OnDestroy()
    {
        Time.timeScale = 1f;
        Physics.gravity = new Vector3(0f, -9.81f, 0f);
        SaveData.Flush();
    }
}
