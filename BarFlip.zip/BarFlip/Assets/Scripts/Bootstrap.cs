using UnityEngine;

// Сцена в проекте пустая. Всё остальное создаётся кодом, когда игра запускается.
public static class Bootstrap
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Init()
    {
        if (Object.FindObjectOfType<GameManager>() != null) return;
        var go = new GameObject("GameManager");
        Object.DontDestroyOnLoad(go);
        go.AddComponent<GameManager>();
    }
}
