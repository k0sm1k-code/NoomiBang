using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Главное меню: слева кнопки, справа в небе на цветной перекладине качается человечек.
// Работает только «Играть» (открывает выбор карт). Остальные кнопки пока показывают «Скоро».
public class MainMenu : MonoBehaviour
{
    Camera cam;
    CameraRig rig;
    Character ch;
    Bar menuBar;
    Canvas canvas;
    GameObject picker;
    Text toastText;
    GameObject toastObj;
    float toastTimer;
    float pumpTimer = 3.4f;
    float colorTimer;
    int colorIdx;

    static readonly Color[] BarColors =
    {
        new Color(0.55f, 0.30f, 0.85f), new Color(0.30f, 0.80f, 0.45f),
        new Color(0.95f, 0.60f, 0.20f), new Color(0.90f, 0.35f, 0.60f)
    };

    static readonly Color PanelDark = new Color(0.09f, 0.08f, 0.07f, 0.94f);
    static readonly Color ItemDark = new Color(0.17f, 0.165f, 0.155f, 1f);
    static readonly Color Cream = new Color(0.94f, 0.92f, 0.86f, 1f);

    void Start()
    {
        cam = GameManager.I.Cam;
        var world = new GameObject("World").transform;
        world.SetParent(transform, false);
        WorldKit.SetupEnvironment(world, cam);

        // перекладина и человечек
        menuBar = Bar.Create(world, "MenuBar", new Vector3(0f, 4f, 1.6f), new Vector3(0f, 4f, -1.6f), BarColors[0]);
        ch = Character.Create(new Vector3(0f, 4f - Character.HandTipY, 0f),
            Quaternion.LookRotation(Vector3.forward, Vector3.up), transform);
        ch.Bars = new List<Bar> { menuBar };
        ch.ForceGrip(menuBar);

        rig = gameObject.AddComponent<CameraRig>();
        rig.Cam = cam;
        rig.Target = ch.Torso.transform;
        rig.Dist = 7f;
        rig.MinY = 0f;
        rig.SideOffset = -3.9f;
        rig.TargetYaw = 0f;
        rig.Snap();

        BuildUi();
    }

    // ---------------------------------------------------------------------------------------
    // Интерфейс
    // ---------------------------------------------------------------------------------------

    void BuildUi()
    {
        canvas = UiKit.CreateCanvas("MenuUI", 10, transform);

        // левая панель
        var left = UiKit.Panel(canvas.transform, "Left", PanelDark, false);
        left.anchorMin = new Vector2(0f, 0f);
        left.anchorMax = new Vector2(0f, 1f);
        left.pivot = new Vector2(0f, 0.5f);
        left.sizeDelta = new Vector2(370f, 0f);
        left.anchoredPosition = Vector2.zero;

        // логотип (рабочий, потом заменить своим) и название
        var logo = UiKit.Panel(left, "Logo", new Color(0.23f, 0.47f, 0.85f, 1f));
        UiKit.PlaceTopLeft(logo, 18f, 16f, 70f, 70f);
        var title = UiKit.Panel(left, "Title", new Color(0f, 0f, 0f, 0f), false);
        UiKit.PlaceTopLeft(title, 102f, 14f, 250f, 44f);
        UiKit.Label(title, "BarFlip", 36, Color.white, TextAnchor.MiddleLeft, FontStyle.Bold);
        var ver = UiKit.Panel(left, "Ver", new Color(0f, 0f, 0f, 0f), false);
        UiKit.PlaceTopLeft(ver, 102f, 58f, 250f, 28f);
        UiKit.Label(ver, "v0.1", 22, new Color(0.7f, 0.7f, 0.7f), TextAnchor.MiddleLeft);

        string[] names = { "Играть", "Мультиплеер", "Маркет", "Перехваты", "Скины", "Визуалы", "Настройки" };
        for (int i = 0; i < names.Length; i++)
        {
            bool play = i == 0;
            var b = UiKit.MakeButton(left, names[i], 30, play ? Cream : ItemDark,
                play ? new Color(0.12f, 0.12f, 0.12f) : new Color(0.93f, 0.93f, 0.93f),
                play ? (UnityEngine.Events.UnityAction)OpenPicker : (() => Toast("Скоро")));
            UiKit.PlaceTopLeft((RectTransform)b.transform, 18f, 104f + i * 76f, 334f, 66f);
            var lab = b.GetComponentInChildren<Text>();
            lab.alignment = TextAnchor.MiddleLeft;
            lab.rectTransform.offsetMin = new Vector2(26f, 0f);
            if (play) lab.fontStyle = FontStyle.Bold;
        }

        // ссылки (пока заглушки)
        var tg = UiKit.MakeButton(left, "TG", 22, ItemDark, Color.white, () => Toast("Скоро"));
        UiKit.PlaceTopLeft((RectTransform)tg.transform, 18f, 650f, 60f, 54f);
        var tt = UiKit.MakeButton(left, "TT", 22, ItemDark, Color.white, () => Toast("Скоро"));
        UiKit.PlaceTopLeft((RectTransform)tt.transform, 88f, 650f, 60f, 54f);

        // профиль и достижения справа сверху
        var prof = UiKit.MakeButton(canvas.transform, "Профиль", 28, PanelDark, Color.white, () => Toast("Скоро"));
        UiKit.PlaceTopRight((RectTransform)prof.transform, 30f, 20f, 220f, 62f);
        var ach = UiKit.MakeButton(canvas.transform, "Достижения", 28, PanelDark, Color.white, () => Toast("Скоро"));
        UiKit.PlaceTopRight((RectTransform)ach.transform, 30f, 96f, 220f, 62f);

        // флаг (русский) справа снизу
        var flag = UiKit.Panel(canvas.transform, "Flag", new Color(0f, 0f, 0f, 0.35f), true);
        UiKit.PlaceBottomRight(flag, 30f, 24f, 70f, 50f);
        var f1 = UiKit.Panel(flag, "w", Color.white, false);
        var f2 = UiKit.Panel(flag, "b", new Color(0.16f, 0.32f, 0.79f), false);
        var f3 = UiKit.Panel(flag, "r", new Color(0.84f, 0.17f, 0.17f), false);
        SetBand(f1, 0f, 1f / 3f);
        SetBand(f2, 1f / 3f, 2f / 3f);
        SetBand(f3, 2f / 3f, 1f);

        // всплывающая подсказка «Скоро»
        toastObj = new GameObject("Toast", typeof(RectTransform));
        toastObj.transform.SetParent(canvas.transform, false);
        var tr = (RectTransform)toastObj.transform;
        UiKit.Place(tr, new Vector2(0.62f, 0f), new Vector2(0.5f, 0f), new Vector2(0f, 90f), new Vector2(260f, 64f));
        var tb = UiKit.Panel(tr, "Bg", new Color(0f, 0f, 0f, 0.72f));
        UiKit.Stretch(tb);
        toastText = UiKit.Label(tb, "", 28, Color.white);
        toastObj.SetActive(false);
    }

    static void SetBand(RectTransform rt, float yMin, float yMax)
    {
        rt.anchorMin = new Vector2(0f, 1f - yMax);
        rt.anchorMax = new Vector2(1f, 1f - yMin);
        rt.offsetMin = new Vector2(4f, 0f);
        rt.offsetMax = new Vector2(-4f, 0f);
        if (yMin == 0f) rt.offsetMax = new Vector2(-4f, -4f);
        if (yMax == 1f) rt.offsetMin = new Vector2(4f, 4f);
    }

    void Toast(string msg)
    {
        toastText.text = msg;
        toastObj.SetActive(true);
        toastTimer = 1.2f;
    }

    // ---------------------------------------------------------------------------------------
    // Окно «Карты»
    // ---------------------------------------------------------------------------------------

    void OpenPicker()
    {
        if (picker != null) return;
        picker = new GameObject("Picker", typeof(RectTransform));
        picker.transform.SetParent(canvas.transform, false);
        UiKit.Stretch((RectTransform)picker.transform);

        var dim = UiKit.Panel(picker.transform, "Dim", new Color(0f, 0f, 0f, 0.45f), false);
        UiKit.Stretch(dim);

        var win = UiKit.Panel(picker.transform, "Window", new Color(0.10f, 0.095f, 0.085f, 0.98f));
        UiKit.Place(win, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(1230f, 690f));

        var title = UiKit.Panel(win, "Title", new Color(0f, 0f, 0f, 0f), false);
        UiKit.PlaceTopLeft(title, 30f, 14f, 400f, 70f);
        UiKit.Label(title, "Карты", 46, Color.white, TextAnchor.MiddleLeft, FontStyle.Bold);

        var close = UiKit.MakeButton(win, "X", 34, ItemDark, Color.white, ClosePicker);
        UiKit.PlaceTopRight((RectTransform)close.transform, 24f, 16f, 66f, 62f);

        // вкладки
        string[] tabs = { "Турники", "Акробатика", "Вода", "Избранное", "Мои карты" };
        var content = new GameObject("Content", typeof(RectTransform));
        content.transform.SetParent(win, false);
        UiKit.Stretch((RectTransform)content.transform);

        var tabButtons = new List<Image>();
        var tabLabels = new List<Text>();
        for (int i = 0; i < tabs.Length; i++)
        {
            int idx = i;
            var tb = UiKit.MakeButton(win, tabs[i], 26, i == 0 ? Cream : ItemDark,
                i == 0 ? new Color(0.12f, 0.12f, 0.12f) : Color.white, null);
            UiKit.PlaceTopLeft((RectTransform)tb.transform, 30f + i * 172f, 100f, 162f, 58f);
            tabButtons.Add(tb.GetComponent<Image>());
            tabLabels.Add(tb.GetComponentInChildren<Text>());
            tb.onClick.AddListener(() =>
            {
                for (int k = 0; k < tabButtons.Count; k++)
                {
                    bool on = k == idx;
                    tabButtons[k].color = on ? Cream : ItemDark;
                    tabLabels[k].color = on ? new Color(0.12f, 0.12f, 0.12f) : Color.white;
                }
                FillMaps(content.transform, idx);
            });
        }

        var sort = UiKit.Panel(win, "Sort", ItemDark);
        UiKit.PlaceTopRight(sort, 30f, 100f, 230f, 58f);
        UiKit.Label(sort, "Сначала новые", 22, new Color(0.9f, 0.9f, 0.9f));

        FillMaps(content.transform, 0);
    }

    void ClosePicker()
    {
        if (picker != null)
        {
            Destroy(picker);
            picker = null;
        }
    }

    void FillMaps(Transform content, int tab)
    {
        for (int i = content.childCount - 1; i >= 0; i--)
        {
            content.GetChild(i).gameObject.SetActive(false);
            Destroy(content.GetChild(i).gameObject);
        }

        if (tab != 0)
        {
            var empty = UiKit.Panel(content, "Empty", new Color(0f, 0f, 0f, 0f), false);
            UiKit.PlaceTopLeft(empty, 30f, 260f, 1170f, 80f);
            UiKit.Label(empty, "Пока пусто", 32, new Color(0.6f, 0.6f, 0.6f));
            return;
        }

        // пока единственная карта
        var card = UiKit.Panel(content, "Card_Classic", new Color(0.20f, 0.19f, 0.17f, 1f));
        UiKit.PlaceTopLeft(card, 30f, 182f, 380f, 270f);
        var btn = card.gameObject.AddComponent<Button>();
        btn.targetGraphic = card.GetComponent<Image>();
        btn.onClick.AddListener(() => GameManager.I.StartGame("classic"));

        var prev = UiKit.Panel(card, "Preview", Color.white);
        prev.GetComponent<Image>().sprite = MakePreview();
        prev.GetComponent<Image>().type = Image.Type.Simple;
        prev.GetComponent<Image>().raycastTarget = false;
        UiKit.PlaceTopLeft(prev, 8f, 8f, 364f, 205f);

        var nm = UiKit.Panel(card, "Name", new Color(0f, 0f, 0f, 0f), false);
        UiKit.PlaceTopLeft(nm, 16f, 218f, 220f, 44f);
        UiKit.Label(nm, "Классика", 32, Color.white, TextAnchor.MiddleLeft, FontStyle.Bold);
        var cat = UiKit.Panel(card, "Cat", new Color(0f, 0f, 0f, 0f), false);
        UiKit.PlaceTopLeft(cat, 236f, 224f, 130f, 36f);
        UiKit.Label(cat, "Турники", 22, new Color(0.62f, 0.62f, 0.62f), TextAnchor.MiddleRight);
    }

    // Картинка-превью карты, нарисованная кодом
    static Sprite MakePreview()
    {
        const int W = 256, H = 160;
        var tex = new Texture2D(W, H, TextureFormat.RGBA32, false);
        tex.filterMode = FilterMode.Bilinear;
        var px = new Color32[W * H];
        Color top = new Color(0.26f, 0.56f, 0.92f);
        Color bottom = new Color(0.80f, 0.90f, 0.98f);
        Color floor = new Color(0.93f, 0.36f, 0.36f);
        Color slab = new Color(0.72f, 0.72f, 0.74f);
        Color cream = new Color(0.93f, 0.91f, 0.85f);
        Color bar = new Color(0.31f, 0.32f, 0.35f);

        for (int y = 0; y < H; y++)
        {
            float t = y / (float)(H - 1);
            Color sky = Color.Lerp(bottom, top, t);
            for (int x = 0; x < W; x++)
            {
                Color c = sky;
                if (y < 34) c = floor;
                else if ((x < 16 || x > W - 17) && y < 128) c = slab;
                px[y * W + x] = c;
            }
        }

        int[] postX = { 52, 84, 116, 148, 180, 212 };
        int[] barY = { 62, 84, 106 };
        for (int p = 0; p < postX.Length; p++)
        {
            for (int y = 34; y < 124; y++)
                for (int x = postX[p]; x < postX[p] + 2; x++)
                    px[y * W + x] = cream;
            for (int b = 0; b < barY.Length; b++)
            {
                if ((p + b) % 2 == 1) continue;
                for (int x = postX[p] - 12; x < postX[p] + 2; x++)
                    px[(barY[b] + (postX[p] - x) / 6) * W + x] = bar;
            }
        }
        tex.SetPixels32(px);
        tex.Apply();
        return Sprite.Create(tex, new Rect(0, 0, W, H), new Vector2(0.5f, 0.5f), 100f);
    }

    // ---------------------------------------------------------------------------------------

    void Update()
    {
        float dt = Time.unscaledDeltaTime;

        // человечек раскачивается сам
        if (ch != null)
        {
            Rigidbody tr = ch.Torso;
            float vx = tr.velocity.x;
            ch.Pose = vx > 0.2f ? BodyPose.Arch : vx < -0.2f ? BodyPose.Tuck : BodyPose.Relaxed;
            pumpTimer += dt;
            if (pumpTimer > 4f && Mathf.Abs(tr.position.x) < 0.3f)
            {
                tr.AddForce(Vector3.right * 12f, ForceMode.Impulse);
                pumpTimer = 0f;
            }
        }

        // перекладина меняет цвет
        colorTimer += dt;
        if (colorTimer > 2.2f && menuBar != null)
        {
            colorTimer = 0f;
            colorIdx = (colorIdx + 1) % BarColors.Length;
            menuBar.SetColor(BarColors[colorIdx]);
        }

        if (toastTimer > 0f)
        {
            toastTimer -= dt;
            if (toastTimer <= 0f) toastObj.SetActive(false);
        }

        if (Input.GetKeyDown(KeyCode.Escape)) ClosePicker();
    }
}
