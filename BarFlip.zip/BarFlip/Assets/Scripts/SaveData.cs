using System.Globalization;
using UnityEngine;

// Перехваты считаются навсегда и не сбрасываются.
public static class SaveData
{
    const string KeyRegrabs = "regrabs";
    static int cached = -1;

    public static int Regrabs
    {
        get
        {
            if (cached < 0) cached = PlayerPrefs.GetInt(KeyRegrabs, 0);
            return cached;
        }
        set
        {
            cached = Mathf.Max(0, value);
            PlayerPrefs.SetInt(KeyRegrabs, cached);
        }
    }

    public static void Flush()
    {
        PlayerPrefs.Save();
    }

    // 4418 -> "4 418" (неразрывный пробел)
    public static string FormatNumber(int n)
    {
        return n.ToString("N0", CultureInfo.InvariantCulture).Replace(',', '\u00A0');
    }

    // Правильное склонение: 1 перехват, 2 перехвата, 5 перехватов.
    public static string RegrabsText(int n)
    {
        int m100 = n % 100;
        int m10 = n % 10;
        string word;
        if (m100 >= 11 && m100 <= 14) word = "перехватов";
        else if (m10 == 1) word = "перехват";
        else if (m10 >= 2 && m10 <= 4) word = "перехвата";
        else word = "перехватов";
        return FormatNumber(n) + " " + word;
    }
}
