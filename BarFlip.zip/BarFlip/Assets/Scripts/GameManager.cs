using UnityEngine;
using UnityEngine.EventSystems;

// Переключает режимы: главное меню <-> игра.
public class GameManager : MonoBehaviour
{
    public static GameManager I { get; private set; }
    public Camera Cam { get; private set; }

    GameObject current;

    void Awake()
    {
        I = this;
        Application.targetFrameRate = 60;
        Screen.sleepTimeout = SleepTimeout.NeverSleep;
        Screen.autorotateToPortrait = false;
        Screen.autorotateToPortraitUpsideDown = false;
        Screen.autorotateToLandscapeLeft = true;
        Screen.autorotateToLandscapeRight = true;
        Screen.orientation = ScreenOrientation.AutoRotation;

        Time.fixedDeltaTime = 0.01f;
        Physics.defaultSolverIterations = 14;
        Physics.defaultSolverVelocityIterations = 4;
        Physics.gravity = new Vector3(0f, -9.81f, 0f);

        EnsureEventSystem();
        CreateCamera();
        ShowMenu();
    }

    void EnsureEventSystem()
    {
        if (FindObjectOfType<EventSystem>() != null) return;
        var es = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
        es.transform.SetParent(transform, false);
    }

    void CreateCamera()
    {
        var go = new GameObject("Main Camera");
        go.tag = "MainCamera";
        go.transform.SetParent(transform, false);
        Cam = go.AddComponent<Camera>();
        go.AddComponent<AudioListener>();
        WorldKit.ConfigureCamera(Cam);
    }

    public void ShowMenu()
    {
        Swap<MainMenu>("Menu");
    }

    public void StartGame(string mapId)
    {
        var s = Swap<GameSession>("Session");
        s.mapId = mapId;
    }

    T Swap<T>(string objName) where T : Component
    {
        if (current != null)
        {
            current.SetActive(false);
            Destroy(current);
        }
        Time.timeScale = 1f;
        Physics.gravity = new Vector3(0f, -9.81f, 0f);
        current = new GameObject(objName);
        current.transform.SetParent(transform, false);
        return current.AddComponent<T>();
    }

    void OnApplicationPause(bool paused)
    {
        if (paused) SaveData.Flush();
    }

    void OnApplicationQuit()
    {
        SaveData.Flush();
    }
}
