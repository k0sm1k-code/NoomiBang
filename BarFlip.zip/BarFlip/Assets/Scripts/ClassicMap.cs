using System.Collections.Generic;
using UnityEngine;

// Карта «Классика»: красная платформа, колонны по краям, ряд столбов с перекладинами на разной высоте.
// Перекладины выходят от столба в сторону камеры и повёрнуты под разными углами, поэтому сцена объёмная.
public static class ClassicMap
{
    static readonly Color FloorC = new Color(0.95f, 0.38f, 0.35f);
    static readonly Color Cream = new Color(0.93f, 0.91f, 0.85f);
    static readonly Color Slab = new Color(0.74f, 0.72f, 0.66f);
    static readonly Color BarC = new Color(0.40f, 0.41f, 0.44f);

    public static List<Bar> Build(Transform root)
    {
        var bars = new List<Bar>();

        // платформа: верх на y = 0, глубина по z от -12 до 12
        WorldKit.Box(root, "Floor", new Vector3(0f, -0.5f, 0f), new Vector3(42f, 1f, 24f), FloorC);

        // колонны по краям
        WorldKit.Box(root, "PillarL", new Vector3(-17.5f, 7f, 0f), new Vector3(2.8f, 14f, 3.2f), Slab);
        WorldKit.Box(root, "PillarR", new Vector3(17.5f, 7f, 0f), new Vector3(2.8f, 14f, 3.2f), Slab);

        // столбы: x, z основания (дальний конец перекладины), поворот перекладин вокруг вертикали
        float[] px = { -13.5f, -9f, -4.5f, 0f, 4.5f, 9f, 13.5f };
        float[] pz = { 2.0f, 1.6f, 2.4f, 1.8f, 2.4f, 1.6f, 2.0f };
        float[] pyaw = { 12f, -18f, 0f, 22f, 0f, -14f, 10f };
        float[][] ph =
        {
            new[] { 4.6f, 8.2f },
            new[] { 6.0f, 9.6f },
            new[] { 4.2f, 7.4f, 10.4f },
            new[] { 5.4f, 8.8f },
            new[] { 4.2f, 7.4f, 10.4f },
            new[] { 6.0f, 9.6f },
            new[] { 4.6f, 8.2f },
        };

        for (int i = 0; i < px.Length; i++)
        {
            float top = 0f;
            for (int k = 0; k < ph[i].Length; k++) top = Mathf.Max(top, ph[i][k]);
            top += 0.9f;

            // столб (без коллайдера: персонаж о него не бьётся)
            WorldKit.Box(root, "Post" + i, new Vector3(px[i], top * 0.5f, pz[i]), new Vector3(0.30f, top, 0.30f), Cream, false, 0.3f);

            for (int k = 0; k < ph[i].Length; k++)
            {
                float yawDeg = pyaw[i] + ((k % 2 == 0) ? 0f : -10f);
                float yr = yawDeg * Mathf.Deg2Rad;
                Vector3 d = new Vector3(Mathf.Sin(yr), 0f, Mathf.Cos(yr));      // от столба вперёд, к камере это -d
                Vector3 a = new Vector3(px[i], ph[i][k], pz[i]);                // у столба
                Vector3 b = a - d * 3.2f;                                       // свободный конец
                bars.Add(Bar.Create(root, "Bar" + i + "_" + k, a, b, BarC));
            }
        }

        // порядок по x, затем по высоте: так номера спавна идут слева направо
        bars.Sort((p, q) =>
        {
            int c = p.A.x.CompareTo(q.A.x);
            return c != 0 ? c : p.A.y.CompareTo(q.A.y);
        });
        return bars;
    }
}
