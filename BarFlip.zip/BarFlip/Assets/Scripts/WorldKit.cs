using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

// Материалы, небо, свет, облака и солнечное свечение. Всё из встроенных шейдеров, без внешних файлов.
public static class WorldKit
{
    static readonly Dictionary<int, Material> cache = new Dictionary<int, Material>();

    // Направление на солнце: слева, за сценой. Свет идёт к камере, поэтому тени ложатся вперёд, к игроку.
    public static readonly Vector3 ToSun = new Vector3(-0.325f, 0.500f, 0.803f);

    // Видимое «солнце» с мягким свечением стоит в небе ниже, как на эталоне (только для красоты).
    public static readonly Vector3 GlowDir = new Vector3(-0.356f, 0.309f, 0.882f);

    static Shader FindShader(params string[] names)
    {
        for (int i = 0; i < names.Length; i++)
        {
            var s = Shader.Find(names[i]);
            if (s != null) return s;
        }
        return null;
    }

    public static Material Mat(Color c, float smooth = 0.05f)
    {
        Color32 k = c;
        int key = (k.r << 24) ^ (k.g << 16) ^ (k.b << 8) ^ k.a ^ (int)(smooth * 100f);
        Material m;
        if (cache.TryGetValue(key, out m) && m != null) return m;
        var shader = FindShader("Standard", "Legacy Shaders/Diffuse", "Sprites/Default");
        m = new Material(shader);
        m.color = c;
        if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", smooth);
        if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", 0f);
        cache[key] = m;
        return m;
    }

    public static Material Unlit(Color c)
    {
        var shader = FindShader("Unlit/Color", "Sprites/Default");
        var m = new Material(shader);
        m.color = c;
        return m;
    }

    public static GameObject Box(Transform parent, string name, Vector3 center, Vector3 size, Color color,
        bool collider = true, float smooth = 0.05f)
    {
        var g = GameObject.CreatePrimitive(PrimitiveType.Cube);
        g.name = name;
        g.transform.SetParent(parent, false);
        g.transform.localPosition = center;
        g.transform.localScale = size;
        g.GetComponent<Renderer>().sharedMaterial = Mat(color, smooth);
        if (!collider) Object.Destroy(g.GetComponent<Collider>());
        return g;
    }

    public static void ConfigureCamera(Camera cam)
    {
        cam.fieldOfView = 50f;
        cam.nearClipPlane = 0.1f;
        cam.farClipPlane = 400f;
        cam.allowHDR = false;
        cam.transform.position = new Vector3(0f, 3f, -8f);
        cam.transform.rotation = Quaternion.identity;
    }

    // ---------------------------------------------------------------------------------------
    // Небо, свет, облака
    // ---------------------------------------------------------------------------------------

    // Небо, свет, солнечное свечение и облака. Возвращает корень, чтобы удалить всё вместе с режимом.
    public static Transform SetupEnvironment(Transform parent, Camera cam)
    {
        var root = new GameObject("Environment").transform;
        root.SetParent(parent, false);
        Vector3 toSun = ToSun.normalized;

        // Небо: насыщенный синий сверху, светлая дымка у горизонта
        var skyShader = Shader.Find("Skybox/Procedural");
        if (skyShader != null)
        {
            var m = new Material(skyShader);
            m.SetFloat("_SunSize", 0.05f);
            m.SetFloat("_SunSizeConvergence", 5f);
            m.SetFloat("_AtmosphereThickness", 0.95f);
            m.SetColor("_SkyTint", new Color(0.42f, 0.55f, 0.85f));
            m.SetColor("_GroundColor", new Color(0.60f, 0.74f, 0.90f));
            m.SetFloat("_Exposure", 1.4f);
            RenderSettings.skybox = m;
            cam.clearFlags = CameraClearFlags.Skybox;
        }
        else
        {
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.45f, 0.70f, 0.95f);
        }

        RenderSettings.ambientMode = AmbientMode.Flat;
        RenderSettings.ambientLight = new Color(0.70f, 0.74f, 0.82f);
        RenderSettings.fog = false;

        // Солнце: мягкие тени
        var lg = new GameObject("Sun");
        lg.transform.SetParent(root, false);
        lg.transform.rotation = Quaternion.LookRotation(-toSun);
        var l = lg.AddComponent<Light>();
        l.type = LightType.Directional;
        l.color = new Color(1f, 0.96f, 0.88f);
        l.intensity = 1.5f;
        l.shadows = LightShadows.Soft;
        l.shadowStrength = 0.75f;
        l.shadowBias = 0.05f;
        l.shadowNormalBias = 0.4f;
        RenderSettings.sun = l;
        QualitySettings.shadows = ShadowQuality.All;
        QualitySettings.shadowResolution = ShadowResolution.Medium;
        QualitySettings.shadowDistance = 60f;
        QualitySettings.shadowCascades = 2;

        MakeSunGlow(root, cam, GlowDir.normalized);
        MakeClouds(root);
        return root;
    }

    // Большое мягкое свечение вокруг солнца: прозрачная картинка в небе, которая едет за камерой.
    static void MakeSunGlow(Transform root, Camera cam, Vector3 toSun)
    {
        const int n = 128;
        var tex = new Texture2D(n, n, TextureFormat.RGBA32, false);
        tex.wrapMode = TextureWrapMode.Clamp;
        tex.filterMode = FilterMode.Bilinear;
        var px = new Color32[n * n];
        for (int y = 0; y < n; y++)
        {
            for (int x = 0; x < n; x++)
            {
                float r = Vector2.Distance(new Vector2((x + 0.5f) / n, (y + 0.5f) / n), new Vector2(0.5f, 0.5f)) * 2f;
                float a = Mathf.Pow(Mathf.Clamp01(1f - r), 2.2f);
                if (r < 0.10f) a = 1f;
                px[y * n + x] = new Color32(235, 250, 255, (byte)Mathf.RoundToInt(Mathf.Clamp01(a) * 255f));
            }
        }
        tex.SetPixels32(px);
        tex.Apply();

        var g = GameObject.CreatePrimitive(PrimitiveType.Quad);
        g.name = "SunGlow";
        Object.Destroy(g.GetComponent<Collider>());
        g.transform.SetParent(root, false);
        g.transform.localScale = new Vector3(150f, 150f, 1f);
        var shader = FindShader("Sprites/Default", "Unlit/Color");
        var mat = new Material(shader);
        mat.mainTexture = tex;
        mat.color = Color.white;
        g.GetComponent<Renderer>().sharedMaterial = mat;
        var follow = g.AddComponent<SkyFollow>();
        follow.Cam = cam.transform;
        follow.Dir = toSun;
        follow.Dist = 250f;
    }

    static Material cloudBottom, cloudMid, cloudTop;

    static void Puff(Transform parent, Material m, Vector3 localPos, Vector3 scale)
    {
        var s = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        Object.Destroy(s.GetComponent<Collider>());
        s.transform.SetParent(parent, false);
        s.transform.localPosition = localPos;
        s.transform.localScale = scale;
        var r = s.GetComponent<Renderer>();
        r.sharedMaterial = m;
        r.shadowCastingMode = ShadowCastingMode.Off;
        r.receiveShadows = false;
    }

    // Облака-кучевые: плоское сероватое основание и белые «шапки» сверху
    static void MakeClouds(Transform root)
    {
        if (cloudBottom == null) cloudBottom = Unlit(new Color(0.74f, 0.80f, 0.90f));
        if (cloudMid == null) cloudMid = Unlit(new Color(0.90f, 0.94f, 0.99f));
        if (cloudTop == null) cloudTop = Unlit(new Color(0.99f, 1f, 1f));

        var rnd = new System.Random(11);
        var holder = new GameObject("Clouds").transform;
        holder.SetParent(root, false);

        for (int i = 0; i < 34; i++)
        {
            float az = (-75f + (float)rnd.NextDouble() * 150f);
            float dist = 70f + (float)rnd.NextDouble() * 80f;
            float w = dist * (0.14f + 0.18f * (float)rnd.NextDouble());
            float y = 5f + (float)rnd.NextDouble() * dist * 0.42f;

            var c = new GameObject("Cloud").transform;
            c.SetParent(holder, false);
            c.position = new Vector3(Mathf.Sin(az * Mathf.Deg2Rad) * dist, y, Mathf.Cos(az * Mathf.Deg2Rad) * dist);
            c.rotation = Quaternion.Euler(0f, az, 0f);

            // основание
            Puff(c, cloudBottom, new Vector3(0f, 0f, 0.04f * w), new Vector3(w, w * 0.22f, w * 0.30f));
            // шапки
            int n = 4 + rnd.Next(3);
            for (int k = 0; k < n; k++)
            {
                float t = n == 1 ? 0.5f : k / (float)(n - 1);
                float hump = Mathf.Clamp01(1f - Mathf.Abs(t - 0.5f) * 1.4f);
                float r = w * (0.15f + 0.15f * hump) * (0.85f + 0.3f * (float)rnd.NextDouble());
                float px = (t - 0.5f) * w * 0.8f;
                Material m = hump > 0.65f ? cloudTop : cloudMid;
                Puff(c, m, new Vector3(px, w * 0.06f + r * 0.45f, -0.02f * w), new Vector3(r * 2f, r * 1.7f, r * 1.6f));
            }
        }
    }
}
