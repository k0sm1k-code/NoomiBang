using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// Небольшой набор помощников для интерфейса, чтобы не делать префабы и сцены руками.
public static class UiKit
{
    static Font _font;
    public static Font Font
    {
        get
        {
            if (_font == null)
            {
                _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                if (_font == null) _font = Font.CreateDynamicFontFromOSFont("Arial", 16);
            }
            return _font;
        }
    }

    static Sprite _rounded;
    public static Sprite Rounded
    {
        get
        {
            if (_rounded == null)
            {
                const int size = 64;
                const int r = 20;
                var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
                tex.filterMode = FilterMode.Bilinear;
                tex.wrapMode = TextureWrapMode.Clamp;
                var px = new Color32[size * size];
                for (int y = 0; y < size; y++)
                {
                    for (int x = 0; x < size; x++)
                    {
                        float cx = Mathf.Clamp(x + 0.5f, r, size - r);
                        float cy = Mathf.Clamp(y + 0.5f, r, size - r);
                        float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(cx, cy));
                        float a = Mathf.Clamp01(r - d + 0.5f);
                        px[y * size + x] = new Color32(255, 255, 255, (byte)Mathf.RoundToInt(a * 255f));
                    }
                }
                tex.SetPixels32(px);
                tex.Apply();
                _rounded = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f, 0,
                    SpriteMeshType.FullRect, new Vector4(r, r, r, r));
            }
            return _rounded;
        }
    }

    static Sprite _roundedSmall;
    public static Sprite RoundedSmall
    {
        get
        {
            if (_roundedSmall == null)
            {
                const int size = 32;
                const int r = 10;
                var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
                tex.filterMode = FilterMode.Bilinear;
                tex.wrapMode = TextureWrapMode.Clamp;
                var px = new Color32[size * size];
                for (int y = 0; y < size; y++)
                {
                    for (int x = 0; x < size; x++)
                    {
                        float cx = Mathf.Clamp(x + 0.5f, r, size - r);
                        float cy = Mathf.Clamp(y + 0.5f, r, size - r);
                        float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), new Vector2(cx, cy));
                        float a = Mathf.Clamp01(r - d + 0.5f);
                        px[y * size + x] = new Color32(255, 255, 255, (byte)Mathf.RoundToInt(a * 255f));
                    }
                }
                tex.SetPixels32(px);
                tex.Apply();
                _roundedSmall = Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f, 0,
                    SpriteMeshType.FullRect, new Vector4(r, r, r, r));
            }
            return _roundedSmall;
        }
    }

    public static Canvas CreateCanvas(string name, int sortOrder, Transform parent)
    {
        var go = new GameObject(name, typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
        go.transform.SetParent(parent, false);
        var c = go.GetComponent<Canvas>();
        c.renderMode = RenderMode.ScreenSpaceOverlay;
        c.sortingOrder = sortOrder;
        var s = go.GetComponent<CanvasScaler>();
        s.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        s.referenceResolution = new Vector2(1600f, 720f);
        s.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
        s.matchWidthOrHeight = 0.5f;
        return c;
    }

    public static RectTransform Panel(Transform parent, string name, Color color, bool rounded = true, bool small = false)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        var img = go.GetComponent<Image>();
        img.color = color;
        if (rounded)
        {
            img.sprite = small ? RoundedSmall : Rounded;
            img.type = Image.Type.Sliced;
        }
        return go.GetComponent<RectTransform>();
    }

    public static Text Label(Transform parent, string text, int size, Color color,
        TextAnchor anchor = TextAnchor.MiddleCenter, FontStyle style = FontStyle.Normal)
    {
        var go = new GameObject("Label", typeof(RectTransform), typeof(Text));
        go.transform.SetParent(parent, false);
        var t = go.GetComponent<Text>();
        t.font = Font;
        t.text = text;
        t.fontSize = size;
        t.color = color;
        t.alignment = anchor;
        t.fontStyle = style;
        t.horizontalOverflow = HorizontalWrapMode.Overflow;
        t.verticalOverflow = VerticalWrapMode.Overflow;
        t.raycastTarget = false;
        Stretch(t.rectTransform);
        return t;
    }

    public static void Stretch(RectTransform rt)
    {
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = Vector2.zero;
        rt.offsetMax = Vector2.zero;
    }

    // Ставит прямоугольник: точка привязки (0..1), опорная точка, позиция от привязки, размер.
    public static void Place(RectTransform rt, Vector2 anchor, Vector2 pivot, Vector2 pos, Vector2 size)
    {
        rt.anchorMin = anchor;
        rt.anchorMax = anchor;
        rt.pivot = pivot;
        rt.anchoredPosition = pos;
        rt.sizeDelta = size;
    }

    // Отступы от левого верхнего угла родителя (как в макете: x вправо, y вниз).
    public static void PlaceTopLeft(RectTransform rt, float x, float y, float w, float h)
    {
        Place(rt, new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(x, -y), new Vector2(w, h));
    }

    public static void PlaceTopRight(RectTransform rt, float x, float y, float w, float h)
    {
        Place(rt, new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(-x, -y), new Vector2(w, h));
    }

    public static void PlaceBottomRight(RectTransform rt, float x, float y, float w, float h)
    {
        Place(rt, new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(-x, y), new Vector2(w, h));
    }

    public static Button MakeButton(Transform parent, string label, int fontSize, Color color, Color textColor,
        UnityAction onClick)
    {
        var rt = Panel(parent, "Button", color);
        var btn = rt.gameObject.AddComponent<Button>();
        btn.targetGraphic = rt.GetComponent<Image>();
        var cb = btn.colors;
        cb.normalColor = Color.white;
        cb.highlightedColor = new Color(0.95f, 0.95f, 0.95f, 1f);
        cb.pressedColor = new Color(0.7f, 0.7f, 0.7f, 1f);
        cb.disabledColor = new Color(0.6f, 0.6f, 0.6f, 0.6f);
        btn.colors = cb;
        if (!string.IsNullOrEmpty(label)) Label(rt, label, fontSize, textColor);
        if (onClick != null) btn.onClick.AddListener(onClick);
        return btn;
    }

    public static HoldButton MakeHold(Transform parent, string name, string label, int fontSize,
        Color normal, Color down, out Text labelText)
    {
        var rt = Panel(parent, name, normal, true, true);
        var hb = rt.gameObject.AddComponent<HoldButton>();
        hb.SetColors(normal, down);
        // тонкая светлая обводка, как у панелей оригинала
        var ol = rt.gameObject.AddComponent<Outline>();
        ol.effectColor = new Color(1f, 1f, 1f, 0.16f);
        ol.effectDistance = new Vector2(1.5f, -1.5f);
        labelText = Label(rt, label, fontSize, new Color(0.93f, 0.95f, 1f, 0.95f), TextAnchor.MiddleCenter, FontStyle.Normal);
        return hb;
    }
}

// Кнопка, у которой важно знать, зажата ли она (позы, винт).
public class HoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
{
    public bool Held { get; private set; }
    public event Action Pressed;
    public event Action Released;

    Image img;
    Color normal = Color.white;
    Color down = Color.gray;

    void Awake()
    {
        img = GetComponent<Image>();
    }

    public void SetColors(Color n, Color d)
    {
        normal = n;
        down = d;
        if (img == null) img = GetComponent<Image>();
        if (img != null) img.color = Held ? down : normal;
    }

    public void OnPointerDown(PointerEventData e)
    {
        Held = true;
        if (img != null) img.color = down;
        if (Pressed != null) Pressed();
    }

    public void OnPointerUp(PointerEventData e)
    {
        Held = false;
        if (img != null) img.color = normal;
        if (Released != null) Released();
    }

    void OnDisable()
    {
        Held = false;
        if (img != null) img.color = normal;
    }
}
