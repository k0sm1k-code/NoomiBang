using UnityEngine;

// Камера в 3D: едет за персонажем и плавно разворачивается, чтобы смотреть вдоль перекладины,
// за которую он держится (так сальто видно сбоку).
public class CameraRig : MonoBehaviour
{
    public Camera Cam;
    public Transform Target;
    public float Zoom = 1f;
    public float Dist = 7.5f;
    public float MinY = 2.4f;
    public float SideOffset = 0f;      // сдвиг вбок относительно взгляда (в меню: персонаж правее центра)
    public float Pitch = 0f;           // наклон камеры вниз в градусах (0 - смотрит горизонтально)
    public float Yaw;                  // текущий поворот камеры вокруг вертикали, градусы
    public float TargetYaw;

    Vector3 vel;
    float yawVel;
    bool snap = true;

    public void Snap()
    {
        snap = true;
    }

    // Развернуть камеру вдоль направления d (по горизонтали), выбрав ближайшую из двух сторон.
    public void LookAlong(Vector3 d)
    {
        Vector3 h = new Vector3(d.x, 0f, d.z);
        if (h.sqrMagnitude < 0.01f) return;
        float y = Mathf.Atan2(h.x, h.z) * Mathf.Rad2Deg;
        if (Mathf.Abs(Mathf.DeltaAngle(TargetYaw, y)) > 90f) y += 180f;
        TargetYaw = y;
    }

    void LateUpdate()
    {
        if (Cam == null || Target == null) return;
        float udt = Time.unscaledDeltaTime;

        if (snap) Yaw = TargetYaw;
        else Yaw = Mathf.SmoothDampAngle(Yaw, TargetYaw, ref yawVel, 0.35f, 360f, udt);

        Quaternion rot = Quaternion.Euler(0f, Yaw, 0f);
        Vector3 fwd = rot * Vector3.forward;
        Vector3 right = rot * Vector3.right;
        Vector3 t = Target.position;
        Vector3 want = t - fwd * (Dist * Zoom) + right * SideOffset;
        want.y = Mathf.Max(t.y + 0.3f, MinY);

        if (snap)
        {
            Cam.transform.position = want;
            vel = Vector3.zero;
            snap = false;
        }
        else
        {
            Cam.transform.position = Vector3.SmoothDamp(Cam.transform.position, want, ref vel, 0.15f, 60f, udt);
        }
        Cam.transform.rotation = Quaternion.Euler(Pitch, Yaw, 0f);
    }
}
