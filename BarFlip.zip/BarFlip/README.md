# BarFlip (рабочее название)

Физическая 3D-игра про акробатику на турниках. Unity 2022.3 LTS. Сцена в проекте пустая, всё создаётся кодом при запуске
(см. `Assets/Scripts/Bootstrap.cs`).

## Что внутри
- `Assets/Scripts/Character.cs` - человечек-рэгдолл: суставы, позы, хват, винт, прилипание, распознавание трюков.
- `Assets/Scripts/GameSession.cs` - игра: кнопки, пауза (замедление, гравитация, масштаб камеры, винт, спавн), камера.
- `Assets/Scripts/MainMenu.cs` - главное меню и окно «Карты» (работает только «Играть», карта «Классика»).
- `Assets/Scripts/ClassicMap.cs` - карта.
- `Assets/Editor/BuildScript.cs` - сборка APK (название и id приложения в начале файла).

## Как собрать APK

### Вариант 1. На компьютере
1. Установить Unity Hub и Unity **2022.3.45f1** (с модулем Android Build Support).
2. Открыть эту папку как проект.
3. Меню **BarFlip -> Build Android APK**. Файл появится в `Builds/Android/`.

### Вариант 2. Без компьютера (GitHub Actions)
1. Залить содержимое папки в репозиторий GitHub (ветка `main`).
2. Получить лицензию Unity для сборки (секрет `UNITY_LICENSE`), см. https://game.ci/docs/github/activation
   (либо секреты `UNITY_EMAIL` и `UNITY_PASSWORD`, если их принимает ваш тип лицензии).
3. Во вкладке **Actions** запустить **Build Android APK**. Готовый APK скачивается из раздела **Artifacts**.

APK собирается с отладочной подписью: подходит для установки на свой телефон, но не для публикации в Google Play.

## Что поменять потом
- Название игры: `BuildScript.cs` (`ProductName`, `ApplicationId`) и надпись в `MainMenu.cs` (`"BarFlip"`).
- Графика: сейчас всё из простых форм (капсулы, кубы). Файлы от автора можно подставить в `Character.cs` и `ClassicMap.cs`.
